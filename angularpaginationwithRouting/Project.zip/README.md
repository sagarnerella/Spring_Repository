A simple way to page through records in a table. Records are populated with ng-repeat and the pager uses UI-Bootstrap. http://angular-ui.github.io/bootstrap/

For convenience I used a record set of 100 records, but you can change it to see the page auto-adjust regardless of the total number of records.